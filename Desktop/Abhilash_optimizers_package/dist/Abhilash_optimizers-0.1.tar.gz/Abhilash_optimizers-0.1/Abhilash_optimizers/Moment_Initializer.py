# -*- coding: utf-8 -*-
"""
Created on Tue Dec 31 13:03:56 2019

@author: 45063883
"""

import math 
import numpy as np

class Moment_Initializer():
    def initialize(momentum_1,momentum_2,turns,theta):
        return momentum_1,momentum_2,turns,theta